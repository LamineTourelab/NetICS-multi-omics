# Raw data explanation
*_Proteome.xlsx --> Raw proteomic data  
Nodule * PhosphoPROT.xlsx --> Raw phosphoproteomic data  
interactions_largest_component.txt --> Reports all interactions of the interaction network's largest component  
network_genes_lar_com_dir.mat --> Reports all unique gene/miRNA names of the interaction network's largest component  
